-- Benger FIX 4: opaque models, separately sorted glazing and moving door COLs.
-- All DFF/COL files share one origin. Do not position door meshes at the portal;
-- the portal coordinates are already baked into their vertices and collision.
local VERSION = "[Benger FIX 4]"
local CONFIG = {
    previewDistance = 22,
    portal = { x = 6.83, y = 0, z = -0.25 },
    doorTravel = 1.18,
    doorDuration = 1100,
    openRadius = 4.2,
    closeRadius = 5.5,
    closeDelay = 1800,
    floorZ = -1.73,
}

local DEFINITIONS = {
    { name = "building", dff = "models/Obje.dff", txd = "room", col = "models/benger.col", collision = true, alpha = false },
    { name = "detail", dff = "models/crypto_garaz_extra.dff", txd = "room", collision = false, alpha = false },
    { name = "garage", dff = "models/garage.dff", txd = "garage", col = "models/garage.col", collision = true, alpha = false },
    { name = "glass", dff = "models/glass.dff", txd = "room", collision = false, alpha = true },
    { name = "door_left", dff = "models/door_left.dff", txd = "room", col = "models/door_left.col", collision = true, alpha = true, direction = -1 },
    { name = "door_right", dff = "models/door_right.dff", txd = "room", col = "models/door_right.col", collision = true, alpha = true, direction = 1 },
}

local models, assets = {}, {}
local objects, scene = {}, nil
local loaded, pollTimer = false, nil
local previousOcclusions = nil

local function say(message, errorMessage)
    outputChatBox(VERSION .. " " .. message, errorMessage and 245 or 225, errorMessage and 110 or 200, errorMessage and 100 or 150)
end

local function suspendPreviewOcclusions()
    if type(getOcclusionsEnabled) ~= "function" or type(setOcclusionsEnabled) ~= "function" then return end
    local ok, enabled = pcall(getOcclusionsEnabled)
    if not ok or type(enabled) ~= "boolean" then return end
    local changed, result = pcall(setOcclusionsEnabled, false)
    if changed and result ~= false then previousOcclusions = enabled end
end

local function restorePreviewOcclusions()
    if previousOcclusions ~= nil and type(setOcclusionsEnabled) == "function" then
        pcall(setOcclusionsEnabled, previousOcclusions)
    end
    previousOcclusions = nil
end

local function destroyScene()
    if isTimer(pollTimer) then killTimer(pollTimer) end
    pollTimer = nil
    for _, object in pairs(objects) do
        if isElement(object) then
            stopObject(object)
            destroyElement(object)
        end
    end
    objects, scene = {}, nil
    restorePreviewOcclusions()
end

local function releaseAssets()
    destroyScene()
    for _, model in pairs(models) do
        engineRestoreModel(model)
        engineRestoreCOL(model)
        engineFreeModel(model)
    end
    models = {}
    for _, asset in ipairs(assets) do
        if isElement(asset) then destroyElement(asset) end
    end
    assets, loaded = {}, false
end

local function requireAsset(loader, path)
    local asset = loader(path)
    if not asset then error("Nie mozna wczytac: " .. path, 0) end
    assets[#assets + 1] = asset
    return asset
end

local function initialize()
    local textures = {
        room = requireAsset(engineLoadTXD, "models/benger.txd"),
        garage = requireAsset(engineLoadTXD, "models/garage.txd"),
    }
    for _, definition in ipairs(DEFINITIONS) do
        local model = engineRequestModel("object", 1337)
        if not model then error("Brak wolnego ID modelu dla: " .. definition.name, 0) end
        models[definition.name] = model
        if not engineImportTXD(textures[definition.txd], model) then
            error("Nie mozna przypisac tekstur: " .. definition.name, 0)
        end
        if definition.col then
            local col = requireAsset(engineLoadCOL, definition.col)
            if not engineReplaceCOL(col, model) then
                error("Nie mozna przypisac kolizji: " .. definition.col, 0)
            end
        end
        local dff = requireAsset(engineLoadDFF, definition.dff)
        -- Do not route opaque walls/props through the transparent object pass.
        if not engineReplaceModel(dff, model, definition.alpha) then
            error("Nie mozna zastapic modelu: " .. definition.dff, 0)
        end
        engineSetModelLODDistance(model, 250)
    end
    loaded = true
end

local function localToWorld(x, y, z)
    local angle = math.rad(scene.rz)
    local sine, cosine = math.sin(angle), math.cos(angle)
    return scene.x + x * cosine - y * sine,
           scene.y + x * sine + y * cosine,
           scene.z + z
end

local function setDoors(open)
    if not scene or scene.doorsOpen == open then return end
    local success = true
    for _, definition in ipairs(DEFINITIONS) do
        if definition.direction then
            local object = objects[definition.name]
            if not isElement(object) then
                success = false
            else
                local offset = open and definition.direction * CONFIG.doorTravel or 0
                local x, y, z = localToWorld(0, offset, 0)
                local cx, cy, cz = getElementPosition(object)
                local distance = math.sqrt((x - cx)^2 + (y - cy)^2 + (z - cz)^2)
                stopObject(object)
                -- A reversal starts at the current position, without jumping.
                local duration = math.max(150, math.floor(CONFIG.doorDuration * math.min(1, distance / CONFIG.doorTravel)))
                if not moveObject(object, duration, x, y, z, 0, 0, 0, "InOutQuad") then
                    success = false
                end
            end
        end
    end
    if success then
        scene.doorsOpen = open
    else
        -- Avoid silently leaving one leaf closed if an object failed mid-scene.
        outputDebugString(VERSION .. " Blad animacji drzwi; usun i utworz podglad ponownie.", 1)
        scene.mode = "error"
    end
end

local function updateDoors()
    if not scene or scene.mode ~= "auto" then return end
    local sameWorld = getElementInterior(localPlayer) == scene.interior
        and getElementDimension(localPlayer) == scene.dimension
    local nearby, remainsNearby = false, false
    if sameWorld then
        local px, py, pz = getElementPosition(localPlayer)
        local x, y, z = localToWorld(CONFIG.portal.x, CONFIG.portal.y, CONFIG.portal.z)
        local distanceSquared = (px - x)^2 + (py - y)^2
        -- Ignore people on a different floor, but also work while in a vehicle.
        local sameFloor = math.abs(pz - z) < 3.2
        nearby = sameFloor and distanceSquared <= CONFIG.openRadius^2
        remainsNearby = sameFloor and distanceSquared <= CONFIG.closeRadius^2
    end
    if nearby then
        scene.awaySince = nil
        setDoors(true)
    elseif remainsNearby and scene.doorsOpen then
        scene.awaySince = nil
    elseif scene.doorsOpen then
        local now = getTickCount()
        if not scene.awaySince then scene.awaySince = now end
        if now - scene.awaySince >= CONFIG.closeDelay then setDoors(false) end
    end
end

local function createPreview()
    if not loaded then
        say("Modele nie sa gotowe. Sprawdz bledy resource w /debugscript 3.", true)
        return
    end
    destroyScene()
    local x, y, z = getElementPosition(localPlayer)
    local _, _, rz = getElementRotation(localPlayer)
    local angle = math.rad(rz)
    -- The floor is -1.73 in model space. Player Z is approximately 1 m above
    -- the ground; this places the inspection floor approximately at ground level.
    scene = {
        x = x - math.sin(angle) * CONFIG.previewDistance,
        y = y + math.cos(angle) * CONFIG.previewDistance,
        z = z - 1 - CONFIG.floorZ,
        rz = rz,
        interior = getElementInterior(localPlayer),
        dimension = getElementDimension(localPlayer),
        doorsOpen = false,
        mode = "auto",
    }
    -- Original map occlusion zones can hide a custom preview behind surfaces
    -- that are not part of this model. Restore the previous setting on cleanup.
    suspendPreviewOcclusions()
    for _, definition in ipairs(DEFINITIONS) do
        local object = createObject(models[definition.name], scene.x, scene.y, scene.z, 0, 0, scene.rz)
        if not object then
            destroyScene()
            say("Nie udalo sie utworzyc calego podgladu. Sprawdz /debugscript 3.", true)
            return
        end
        objects[definition.name] = object
        setElementInterior(object, scene.interior)
        setElementDimension(object, scene.dimension)
        setElementCollisionsEnabled(object, definition.collision)
        -- Source meshes already provide the required front/back faces.
        -- Forcing two-sided rendering exposes overlapping coplanar surfaces.
        setElementDoubleSided(object, false)
        setObjectBreakable(object, false)

    end
    pollTimer = setTimer(updateDoors, 150, 0)
    updateDoors()
    say("Podglad 22 m przed Toba. Wejscie z przodu; garaz po prawej, za szklanymi drzwiami.")
    say("Drzwi otwieraja sie przy podejsciu. /bengerdrzwi: tryb drzwi; /bengerusun: usuniecie.")
end

-- FIX 4 has its own entry point, so an old /benger handler cannot also spawn
-- a second version when the user runs the recommended preview command.
addCommandHandler("bengerfix", createPreview)
addCommandHandler("benger", createPreview)
addCommandHandler("bengerusun", function()
    destroyScene()
    say("Podglad usuniety.")
end)
addCommandHandler("bengerdrzwi", function()
    if not scene then
        say("Najpierw utworz podglad komenda /bengerfix.")
        return
    end
    if scene.mode == "auto" then
        scene.mode = "open"
        setDoors(true)
        say("Drzwi stale otwarte. Kolejne /bengerdrzwi: zamkniecie.")
    elseif scene.mode == "open" then
        scene.mode = "closed"
        setDoors(false)
        say("Drzwi stale zamkniete. Kolejne /bengerdrzwi: automatyka.")
    else
        scene.mode = "auto"
        scene.awaySince = nil
        updateDoors()
        say("Automatyczne drzwi wlaczone.")
    end
end)

addCommandHandler("bengerinfo", function()
    local modelCount, objectCount = 0, 0
    local identifiers = {}
    for _, definition in ipairs(DEFINITIONS) do
        local model = models[definition.name]
        if model then
            modelCount = modelCount + 1
            identifiers[#identifiers + 1] = definition.name .. "=" .. tostring(model)
        end
        if isElement(objects[definition.name]) then objectCount = objectCount + 1 end
    end
    say("Resource 4.0; gotowy=" .. tostring(loaded) .. "; modele=" .. modelCount .. "/6; obiekty=" .. objectCount .. "/6.")
    if #identifiers > 0 then say("ID: " .. table.concat(identifiers, ", ")) end
    if type(getOcclusionsEnabled) == "function" then
        local ok, enabled = pcall(getOcclusionsEnabled)
        if ok and type(enabled) == "boolean" then
            say("Okluzja mapy=" .. tostring(enabled) .. "; zmiana podgladu=" .. tostring(previousOcclusions ~= nil) .. ".")
        end
    end
end)

local function warnAboutPreviousVersions()
    -- Some client builds do not expose resource-state inspection. The README
    -- always gives explicit stop commands; absence of this API is not an error.
    if type(getResourceFromName) ~= "function" or type(getResourceState) ~= "function" then return end
    for _, name in ipairs({ "benger_garage", "benger_garage_v2", "benger_original_garaz" }) do
        local previous = getResourceFromName(name)
        if previous and getResourceState(previous) == "running" then
            say("Dziala tez " .. name .. ". Zatrzymaj starszy resource w konsoli serwera, aby uniknac nakladania modeli.", true)
        end
    end
end

addEventHandler("onClientResourceStart", resourceRoot, function()
    local ok, message = pcall(initialize)
    if not ok then
        releaseAssets()
        outputDebugString(VERSION .. " " .. tostring(message), 1)
        say("Blad wczytywania modeli. Sprawdz /debugscript 3.", true)
        return
    end
    warnAboutPreviousVersions()
    say("Resource 4.0 gotowy. /bengerfix tworzy podglad FIX 4; /bengerinfo pokazuje wersje i ID modeli.")
end)
addEventHandler("onClientResourceStop", resourceRoot, releaseAssets)
