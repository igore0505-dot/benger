BENGER FIX 4 — ORYGINALNE WNĘTRZE + DOSTARCZONY GARAŻ

POPRAWKA WYŚWIETLANIA I KOLIZJI
Nieprzezroczyste ściany, wyposażenie i garaż są wczytywane bez wymuszania
sortowania przezroczystości. Stałe szyby wydzielono do osobnego glass.dff;
przezroczystość włączona jest tylko dla szyb i ruchomych szklanych drzwi.
Skrypt nie wymusza dwustronnego rysowania źródłowych, prawidłowo obróconych
powierzchni. Garaż korzysta z własnego garage.col, a wnętrze z benger.col.
Każde skrzydło ma własną kolizję, która odsuwa się razem z drzwiami.
Na czas własnego podglądu skrypt wyłącza strefy okluzji oryginalnej mapy,
które mogą zasłaniać obcy model zależnie od ustawienia kamery. Po usunięciu
podglądu, błędzie jego tworzenia lub zatrzymaniu resource przywraca poprzedni
stan. Jeśli klient nie udostępnia tych funkcji, podgląd działa bez tej zmiany.

Wnętrze pochodzi z Obje i crypto_garaz_extra, garaż z przesłanych 1.dff/1.col/1.txd.
Przejście i przesuwne drzwi zachowują położenie poprzedniej wersji.
Ta poprawka nie dodaje nowego projektu wnętrza ani wyposażenia.

INSTALACJA MTA:SA 1.6 — ZASTĄP POPRZEDNIĄ WERSJĘ
1. Zatrzymaj wcześniejsze paczki w konsoli serwera:
   stop benger_garage
   stop benger_garage_v2
   stop benger_original_garaz
   Jeśli wgrywasz tę poprawkę ponownie: stop benger_original_garaz_fix
   Jeśli ręcznie zmieniałeś nazwy wcześniejszych folderów, zatrzymaj także
   te własne kopie. Jednocześnie powinna działać tylko jedna wersja.
2. Wgraj cały nowy folder benger_original_garaz_fix do resources.
   Przy ponownym wgrywaniu FIX 4 zastąp jego pliki kompletną zawartością paczki.
3. W konsoli serwera: refresh
   Następnie: start benger_original_garaz_fix
4. W grze sprawdź komunikat [Benger FIX 4] i wpisz /bengerinfo.
   Po wpisaniu /bengerfix powinno być: modele=6/6; obiekty=6/6.
   Inny prefiks oznacza, że odzywa się wcześniejsza paczka.
5. Stań na pustym, płaskim terenie i wpisz /bengerfix.
   Podgląd stanie 22 m przed postacią; skrypt nie teleportuje gracza.

KOMENDY
/bengerfix    — zalecana komenda FIX 4; tworzy podgląd i usuwa swój poprzedni.
/benger       — zgodny ze starszymi wersjami alias; używaj po ich zatrzymaniu.
/bengerusun   — usuwa wyłącznie podgląd należący do tej poprawki.
/bengerdrzwi  — przełącza automatykę / stale otwarte / stale zamknięte.
/bengerinfo   — pokazuje wersję, modele/obiekty, ID i dostępny stan okluzji.

Nie uruchamiaj starszych paczek razem z poprawką: używają tych samych komend
i mogą nakładać identyczne powierzchnie. Używaj /bengerfix, aby nie uruchomić
przypadkiem dawnego handlera /benger. FIX 4 sam nie zatrzymuje innych
resource i nie usuwa ich obiektów. Gdy klient udostępnia odczyt stanu resource,
skrypt ostrzega o uruchomionych wcześniejszych paczkach pod znanymi nazwami.

PRZYPISANIE PLIKÓW
Wszystkie modele i kolizje mają wspólny punkt odniesienia oraz obrót:
- Obje.dff: nieprzezroczyste wnętrze; benger.txd i benger.col.
- crypto_garaz_extra.dff: nieprzezroczyste detale; benger.txd, kolizja wyłączona,
  bo odpowiednie przeszkody obejmuje kolizja głównego wnętrza.
- garage.dff: dostarczony garaż; garage.txd i garage.col, kolizja włączona.
- glass.dff: stałe szyby wnętrza; benger.txd, bez dodatkowej kolizji obiektu.
- door_left.dff / door_right.dff: benger.txd i odpowiadające im ruchome COL.

Nie przesuwaj osobno garażu, szyb ani zamkniętych drzwi na pozycję przejścia:
położenie jest już zapisane w geometrii. Poziom posadzki to lokalne Z ≈ -1,73 m,
przejście znajduje się przy X ≈ 6,83 m, Y = 0. Każde skrzydło odsuwa się
o 1,18 m po lokalnej osi Y; skrypt uwzględnia obrót całego budynku.

Podgląd jest lokalny dla gracza. Do stałej, współdzielonej mapy ustaw własny
wspólny punkt oraz obrót i zsynchronizuj obiekty/stany drzwi po stronie serwera.

KONTROLA PO WGRANIU
Obejdź model z kilku stron, poruszając kamerą; sprawdź ściany i wyposażenie.
Sprawdź przejście pieszo i kolizję przy elementach wyposażenia oraz samochodem
w garażu. Podejdź do drzwi, poczekaj na otwarcie, następnie odejdź i sprawdź
zamknięcie. W razie błędu użyj /debugscript 3 oraz /bengerinfo.
Logika resource jest sprawdzana z atrapami API MTA; końcowy wygląd i kolizję
należy potwierdzić w uruchomionej grze.
