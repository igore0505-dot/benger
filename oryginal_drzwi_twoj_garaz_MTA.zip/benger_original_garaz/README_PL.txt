ORYGINALNE WNETRZE + DRZWI + TWOJ GARAZ

Wnetrze pochodzi z Twoich poczatkowych plikow Obje i crypto_garaz_extra.
Usunieto projekt poprzednich autorskich przerobek. Nie dodano nowego wystroju.
Jedyna zmiana w dawnym wnetrzu to przejscie w srodkowej czesci prawej sciany
oraz kopia oryginalnych przesuwnych drzwi.
Za nimi znajduje sie model z przeslanych 1.dff / 1.col / 1.txd.
Garaz obrocono do pionu i przesunieto, bez zmiany skali. Wyglad, UV i tekstury
pozostaja jego wlasne. Wyjeto tylko fragment bocznej sciany pod przejscie.
Tekstury garage.txd sa bajt w bajt identyczne z przeslanym 1.txd.
Kolizja garazu pochodzi z 1.col; dopasowano otwor i poziom podlogi.
Oryginalna brama garazu pozostaje statyczna tak jak w przeslanym modelu.

MTA 1.6
1. Rozpakuj folder benger_original_garaz do resources.
2. Zatrzymaj poprzednie wersje: stop benger_garage_v2 oraz stop benger_garage.
3. refresh
4. start benger_original_garaz
5. W grze wpisz /benger na pustym, plaskim terenie.
   Podglad pojawia sie 22 m przed postacia. Drzwi do garazu otwieraja sie
   przy podejsciu. /bengerdrzwi przelacza tryby; /bengerusun usuwa podglad.

Podglad jest lokalny dla gracza, nie jest wspoldzielona mapa serwerowa.
Do stalego montazu ustaw w client.lua wspolny punkt i obrot wszystkich modeli.
Wszystkie DFF i COL maja wspolny punkt odniesienia; nie przesuwaj dodatkowo
garage.dff ani modeli drzwi na pozycje otworu, bo te pozycje sa juz w geometrii.
Model garazu uzywa osobnego garage.txd i garage.col. Pozostale modele uzywaja
benger.txd. Glowny Obje ma benger.col; detal ma wylaczona kolizje, bo jest ona
w benger.col. Oba skrzydla maja osobne, ruchome COL.

Sprawdzono pliki, zgodnosc geometrii/UV garazu poza otworem, oba poziomy podlogi,
przejscie po otwarciu, blokowanie zamknietych skrzydel oraz logike Lua z atrapami
API. Nie wykonywano testu w dzialajacym kliencie GTA/MTA.
Podglady sa renderami Blendera, nie zrzutami z gry.

Zrodlo modelu odnosi sie do osi Z=-1.734 dla podlogi; portal lezy przy X=6.832,Y=0.
