-- Oryginalne wnetrze + dostarczony garaz: local inspection resource for MTA:SA 1.6.
-- All DFF/COL files share one origin. Do not position door meshes at the portal;
-- the portal coordinates are already baked into their vertices and collision.
local CONFIG = {
    previewDistance = 22,
    portal = { x = 6.83, y = 0, z = -0.25 },
    doorTravel = 1.18,
    doorDuration = 1100,
    openRadius = 4.2,
    closeRadius = 5.5,
    closeDelay = 1800,
    floorZ = -1.73,
}

local DEFINITIONS = {
    { name = "building", dff = "models/Obje.dff", col = "models/benger.col", collision = true },
    { name = "detail", dff = "models/crypto_garaz_extra.dff", collision = false },
    { name = "garage", dff = "models/garage.dff", col = "models/garage.col", collision = true },
    { name = "door_left", dff = "models/door_left.dff", col = "models/door_left.col", collision = true, direction = -1 },
    { name = "door_right", dff = "models/door_right.dff", col = "models/door_right.col", collision = true, direction = 1 },
}

local models, assets = {}, {}
local objects, scene = {}, nil
local loaded, pollTimer = false, nil

local function say(message, errorMessage)
    outputChatBox("[Benger] " .. message, errorMessage and 245 or 225, errorMessage and 110 or 200, errorMessage and 100 or 150)
end

local function destroyScene()
    if isTimer(pollTimer) then killTimer(pollTimer) end
    pollTimer = nil
    for _, object in pairs(objects) do
        if isElement(object) then
            stopObject(object)
            destroyElement(object)
        end
    end
    objects, scene = {}, nil
end

local function releaseAssets()
    destroyScene()
    for _, model in pairs(models) do
        engineRestoreModel(model)
        engineRestoreCOL(model)
        engineFreeModel(model)
    end
    models = {}
    for _, asset in ipairs(assets) do
        if isElement(asset) then destroyElement(asset) end
    end
    assets, loaded = {}, false
end

local function requireAsset(loader, path)
    local asset = loader(path)
    if not asset then error("Nie mozna wczytac: " .. path, 0) end
    assets[#assets + 1] = asset
    return asset
end

local function initialize()
    local txd = requireAsset(engineLoadTXD, "models/benger.txd")
    local garageTXD = requireAsset(engineLoadTXD, "models/garage.txd")
    for _, definition in ipairs(DEFINITIONS) do
        local model = engineRequestModel("object", 1337)
        if not model then error("Brak wolnego ID modelu dla: " .. definition.name, 0) end
        models[definition.name] = model
        if not engineImportTXD(definition.name == "garage" and garageTXD or txd, model) then
            error("Nie mozna przypisac tekstur: " .. definition.name, 0)
        end
        if definition.col then
            local col = requireAsset(engineLoadCOL, definition.col)
            if not engineReplaceCOL(col, model) then
                error("Nie mozna przypisac kolizji: " .. definition.col, 0)
            end
        end
        local dff = requireAsset(engineLoadDFF, definition.dff)
        if not engineReplaceModel(dff, model, true) then
            error("Nie mozna zastapic modelu: " .. definition.dff, 0)
        end
        engineSetModelLODDistance(model, 250)
    end
    loaded = true
end

local function localToWorld(x, y, z)
    local angle = math.rad(scene.rz)
    local sine, cosine = math.sin(angle), math.cos(angle)
    return scene.x + x * cosine - y * sine,
           scene.y + x * sine + y * cosine,
           scene.z + z
end

local function setDoors(open)
    if not scene or scene.doorsOpen == open then return end
    local success = true
    for _, definition in ipairs(DEFINITIONS) do
        if definition.direction then
            local object = objects[definition.name]
            if not isElement(object) then
                success = false
            else
                local offset = open and definition.direction * CONFIG.doorTravel or 0
                local x, y, z = localToWorld(0, offset, 0)
                local cx, cy, cz = getElementPosition(object)
                local distance = math.sqrt((x - cx)^2 + (y - cy)^2 + (z - cz)^2)
                stopObject(object)
                -- A reversal starts at the current position, without jumping.
                local duration = math.max(150, math.floor(CONFIG.doorDuration * math.min(1, distance / CONFIG.doorTravel)))
                if not moveObject(object, duration, x, y, z, 0, 0, 0, "InOutQuad") then
                    success = false
                end
            end
        end
    end
    if success then
        scene.doorsOpen = open
    else
        -- Avoid silently leaving one leaf closed if an object failed mid-scene.
        outputDebugString("Benger: blad animacji drzwi; usun i utworz podglad ponownie.", 1)
        scene.mode = "error"
    end
end

local function updateDoors()
    if not scene or scene.mode ~= "auto" then return end
    local sameWorld = getElementInterior(localPlayer) == scene.interior
        and getElementDimension(localPlayer) == scene.dimension
    local nearby, remainsNearby = false, false
    if sameWorld then
        local px, py, pz = getElementPosition(localPlayer)
        local x, y, z = localToWorld(CONFIG.portal.x, CONFIG.portal.y, CONFIG.portal.z)
        local distanceSquared = (px - x)^2 + (py - y)^2
        -- Ignore people on a different floor, but also work while in a vehicle.
        local sameFloor = math.abs(pz - z) < 3.2
        nearby = sameFloor and distanceSquared <= CONFIG.openRadius^2
        remainsNearby = sameFloor and distanceSquared <= CONFIG.closeRadius^2
    end
    if nearby then
        scene.awaySince = nil
        setDoors(true)
    elseif remainsNearby and scene.doorsOpen then
        scene.awaySince = nil
    elseif scene.doorsOpen then
        local now = getTickCount()
        if not scene.awaySince then scene.awaySince = now end
        if now - scene.awaySince >= CONFIG.closeDelay then setDoors(false) end
    end
end

local function createPreview()
    if not loaded then
        say("Modele nie sa gotowe. Sprawdz bledy resource w /debugscript 3.", true)
        return
    end
    destroyScene()
    local x, y, z = getElementPosition(localPlayer)
    local _, _, rz = getElementRotation(localPlayer)
    local angle = math.rad(rz)
    -- The floor is -1.73 in model space. Player Z is approximately 1 m above
    -- the ground; this places the inspection floor approximately at ground level.
    scene = {
        x = x - math.sin(angle) * CONFIG.previewDistance,
        y = y + math.cos(angle) * CONFIG.previewDistance,
        z = z - 1 - CONFIG.floorZ,
        rz = rz,
        interior = getElementInterior(localPlayer),
        dimension = getElementDimension(localPlayer),
        doorsOpen = false,
        mode = "auto",
    }
    for _, definition in ipairs(DEFINITIONS) do
        local object = createObject(models[definition.name], scene.x, scene.y, scene.z, 0, 0, scene.rz)
        if not object then
            destroyScene()
            say("Nie udalo sie utworzyc calego podgladu. Sprawdz /debugscript 3.", true)
            return
        end
        objects[definition.name] = object
        setElementInterior(object, scene.interior)
        setElementDimension(object, scene.dimension)
        setElementCollisionsEnabled(object, definition.collision)
        setElementDoubleSided(object, true)
        setObjectBreakable(object, false)

    end
    pollTimer = setTimer(updateDoors, 150, 0)
    updateDoors()
    say("Podglad 22 m przed Toba. Wejscie z przodu; garaz po prawej, za szklanymi drzwiami.")
    say("Drzwi otwieraja sie przy podejsciu. /bengerdrzwi: tryb drzwi; /bengerusun: usuniecie.")
end

addCommandHandler("benger", createPreview)
addCommandHandler("bengerusun", function()
    destroyScene()
    say("Podglad usuniety.")
end)
addCommandHandler("bengerdrzwi", function()
    if not scene then
        say("Najpierw utworz podglad komenda /benger.")
        return
    end
    if scene.mode == "auto" then
        scene.mode = "open"
        setDoors(true)
        say("Drzwi stale otwarte. Kolejne /bengerdrzwi: zamkniecie.")
    elseif scene.mode == "open" then
        scene.mode = "closed"
        setDoors(false)
        say("Drzwi stale zamkniete. Kolejne /bengerdrzwi: automatyka.")
    else
        scene.mode = "auto"
        scene.awaySince = nil
        updateDoors()
        say("Automatyczne drzwi wlaczone.")
    end
end)

addEventHandler("onClientResourceStart", resourceRoot, function()
    local ok, message = pcall(initialize)
    if not ok then
        releaseAssets()
        outputDebugString("Benger: " .. tostring(message), 1)
        say("Blad wczytywania modeli. Sprawdz /debugscript 3.", true)
        return
    end
    say("Garage v2 gotowy. /benger tworzy lokalny podglad modelu.")
end)
addEventHandler("onClientResourceStop", resourceRoot, releaseAssets)
