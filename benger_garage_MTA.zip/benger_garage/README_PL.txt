BENGER GARAGE — przerobka modeli GTA SA / MTA

Zawartosc:
- oryginalne wnetrze z dodatkowym portalem w prawej scianie;
- nowy garaz ok. 10 x 9 m, dwa stanowiska, otwarte drzwi;
- grafitowe sciany, metalowe detale, oznaczenia stanowisk;
- stol warsztatowy, szafki, narzedzia i oprawy swietlne;
- uproszczona kolizja z przejsciem do garazu;
- wspolny TXD zawierajacy tekstury z obu plikow zrodlowych.

INSTALACJA PODGLADU
1. Wstaw folder benger_garage do resources serwera MTA 1.6.
2. W konsoli serwera: refresh, nastepnie start benger_garage.
3. W grze wpisz /benger. Model pojawi sie 30 m w kierunku +Y.
   Uzyj pustego, plaskiego miejsca; /bengerusun usuwa podglad.
   Model podgladowy jest lokalny, widoczny tylko dla osoby wywolujacej komende.
4. Oba modele musza miec identyczne polozenie i obrot.
   Dla stalego mapowania zastap komende wlasnymi createObject oraz synchronizacja.

UWAGI
To pierwsza wersja projektowa. Nie testowano jej w kliencie GTA/MTA.
Sprawdzono odczyt eksportu, nazwy tekstur i strukture kolizji poza gra.
Otwarte skrzydla drzwi sa statyczne; nie ma animacji otwierania.
Pasy LED to geometria o jasnych materialach. Emisja z renderu Blendera nie
przenosi sie do GTA; dynamiczne swiatlo wymaga osobnego shadera/skryptu MTA.
Zrzut referencyjny nie zawiera wspolrzednych: portal umieszczono w srodkowej
czesci prawej sciany (+X). Dokladne dopasowanie do istniejacej mapy trzeba
sprawdzic w grze. Kolizja jest nowa i uproszczona, nie kopiuje kazdego rekwizytu.
Nie zmieniono oryginalnych zalacznikow.
