-- Client-side preview. Both meshes use the same origin and rotation.
local ids, assets, objects = {}, {}, {}
local function clearObjects()
    for _, o in ipairs(objects) do if isElement(o) then destroyElement(o) end end
    objects = {}
end
addEventHandler('onClientResourceStart', resourceRoot, function()
    local paths = {'models/Obje.dff', 'models/crypto_garaz_extra.dff'}
    for i, path in ipairs(paths) do
        local id = engineRequestModel('object', 1337)
        if not id then outputDebugString('Benger: no free model ID', 1) return end
        ids[i] = id
        local txd = engineLoadTXD('models/benger.txd')
        local col = engineLoadCOL('models/benger.col')
        local dff = engineLoadDFF(path)
        if txd then assets[#assets + 1] = txd end
        if col then assets[#assets + 1] = col end
        if dff then assets[#assets + 1] = dff end
        if not (txd and col and dff) then
            outputDebugString('Benger: asset loading failed: '..path, 1) return
        end
        if not (engineImportTXD(txd, id) and engineReplaceCOL(col, id) and engineReplaceModel(dff, id, true)) then
            outputDebugString('Benger: model replacement failed: '..path, 1) return
        end
        engineSetModelLODDistance(id, 200)
    end
    outputChatBox('Benger: /benger - pokaz model; /bengerusun - usun podglad.', 220, 190, 120)
end)
addCommandHandler('benger', function()
    if #ids ~= 2 then return end
    clearObjects()
    local x, y, z = getElementPosition(localPlayer)
    -- Place the building 30 m in front along world Y; origin Z is 1.73 m above floor.
    y = y + 30
    z = z + 0.75
    for _, id in ipairs(ids) do
        local o = createObject(id, x, y, z)
        if o then
            setElementInterior(o, getElementInterior(localPlayer))
            setElementDimension(o, getElementDimension(localPlayer))
            setElementDoubleSided(o, true)
            objects[#objects + 1] = o
        end
    end
    outputChatBox('Model stoi 30 m w kierunku +Y. Wejscie: od strony -Y; garaz: prawa strona.', 220, 190, 120)
end)
addCommandHandler('bengerusun', clearObjects)
addEventHandler('onClientResourceStop', resourceRoot, function()
    clearObjects()
    for _, id in ipairs(ids) do engineFreeModel(id) end
end)
