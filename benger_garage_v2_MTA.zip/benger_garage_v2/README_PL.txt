BENGER GARAGE v2 — model GTA San Andreas / MTA:SA 1.6

Przejście z oryginalnego wnętrza prowadzi do nowego garażu 15 × 12,8 m.
Szklane skrzydła są skopiowane z geometrii oryginalnego wejścia, razem
z materiałami i mapowaniem tekstur: te same ramy, szkło i jasne uchwyty.
Otwierają się przy podejściu; ich kolizja przesuwa się razem z nimi.

Garaż ma dwa wjazdy ze stałymi, podniesionymi roletami, dwa stanowiska
serwisowe (jedno z niskim podnośnikiem nożycowym), sufitowe oprawy LED
w kształcie plastrów miodu, zabudowę warsztatową, regał na opony, kompresor
i punkty ładowania. Nowe tekstury mają pełne, zapisane w TXD mipmapy.

Drewniana ściana ze zrzutu nie występowała w przesłanej geometrii.
Lamele odtworzono, a przejście umieszczono pośrodku prawej ściany wnętrza.

INSTALACJA I PODGLĄD
1. Rozpakuj cały folder benger_garage_v2 do resources na serwerze MTA:SA 1.6.
2. Jeśli działa starsza wersja, wpisz w konsoli serwera: stop benger_garage
   Obie wersje używają tych samych komend — uruchomiona ma być tylko v2.
3. Wpisz: refresh
   Następnie: start benger_garage_v2
4. W grze stań na dużym, pustym, płaskim terenie i wpisz: /benger
   Model stanie około 22 m przed postacią, obrócony zgodnie z jej kierunkiem.
   Skrypt nie teleportuje gracza. Wysokość jest przybliżona względem postaci.
   Gdy teren jest nierówny, podgląd może wymagać innego miejsca.
5. Podejdź do szklanych drzwi po prawej stronie wnętrza. Oba skrzydła rozsuną
   się na boki, a po odejściu zamkną z opóźnieniem.

KOMENDY
/benger       — tworzy lub zastępuje lokalny podgląd.
/bengerusun   — usuwa podgląd i jego kolizję.
/bengerdrzwi  — przełącza: automatyka → stale otwarte → stale zamknięte → automatyka.

Ten resource jest podglądem po stronie klienta. Widzi go wyłącznie gracz,
który wpisał /benger. Pozostali gracze nie współdzielą obiektów ani stanu drzwi.
Podgląd używa interioru i dimension gracza z chwili utworzenia. Drzwi nie
reagują na gracza z innego interioru/dimension ani z wyraźnie innej kondygnacji.

PLIKI I MONTAŻ NA WŁASNEJ MAPIE
Wszystkie modele mają wspólny punkt odniesienia i ten sam obrót:
- Obje.dff: główne oryginalne wnętrze; używa statycznej kolizji benger.col.
- crypto_garaz_extra.dff: elementy oryginalnego wnętrza; kolizja wyłączona.
- garage.dff: dobudowany garaż; kolizja wyłączona, bo zawiera ją benger.col.
- door_left.dff i door_right.dff: ruchome skrzydła z osobnymi plikami COL.
- benger.txd: wspólne tekstury wszystkich pięciu modeli.

Nie przesuwaj obu modeli drzwi na współrzędne otworu. Ich geometria i kolizja
mają już wbudowaną pozycję wejścia; zamknięte obiekty stoją w tym samym punkcie
co pozostałe modele. Przy otwieraniu skrypt dodaje przesunięcie w lokalnej osi Y.
Przelicza je także po obróceniu całego budynku, więc drzwi nadal trafiają w otwór.
Nie dodawaj dodatkowej nieruchomej kolizji w otworze drzwiowym.

Zerowy poziom posadzki modelu to lokalne Z = -1,73 m. Otwór do garażu znajduje
się przy lokalnym X = 6,83 m i Y = 0. Poszczególne pozycje i odległości są
opisane na początku client.lua. Do stałego montażu ustaw wspólne współrzędne
i obrót zamiast pozycji wyliczanej przez createPreview. Do współdzielonego
garażu serwerowego trzeba dodać synchronizowane obiekty i stan drzwi.

ŚWIATŁO I MATERIAŁY
Opcjonalny shader shaders/led.fx jest przypisany wyłącznie do tekstur
bg_led_white i bg_led_amber na obiektach tego resource. Utrzymuje ich jasny
wygląd także nocą. Nie emituje światła na sąsiednie ściany ani samochody.
Jeżeli karta graficzna nie obsłuży shadera, modele pozostają dostępne ze
standardowymi materiałami. Render podglądowy może różnić się od MTA.

SPRAWDZENIE W GRZE
Po montażu sprawdź dopasowanie przejścia, otwieranie obu skrzydeł, przejazd
pojazdem, wysokość posadzki, szkło i wygląd w dzień oraz w nocy.
W razie błędu wczytywania użyj /debugscript 3. Resource zgłasza nazwę pliku,
zwalnia częściowo wczytane modele i nie tworzy niekompletnego podglądu.
Nie deklarujemy testu w uruchomionym kliencie GTA/MTA: w tej maszynie nie ma gry.

Oryginalne przesłane załączniki pozostają bez zmian; paczka zawiera nową wersję.
Plik źródłowy .blend jest dostarczany osobno od resource. Dachy pozostają
kompletne w modelach gry i pliku źródłowym; widoki odsłaniające wnętrze
służą wyłącznie prezentacji wyposażenia.
