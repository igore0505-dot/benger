// Read the object's original stage-0 texture and omit the lighting multiplier.
// This keeps LED strips legible at night; it does not light nearby surfaces.
sampler2D originalTexture : register(s0);

float4 unlitLED(float2 uv : TEXCOORD0) : COLOR0
{
    return tex2D(originalTexture, uv);
}

technique LED
{
    pass P0
    {
        PixelShader = compile ps_2_0 unlitLED();
    }
}
